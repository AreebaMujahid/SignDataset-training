import glob
import os
import numpy as np
import torch
from torch.utils.data import Dataset
from PIL import Image
import torchvision.transforms as transforms

mean = np.array([0.5])
std = np.array([0.5])

class SignDataset(Dataset):
    def __init__(self, root, hr_shape):
        hr_height, hr_width = hr_shape
        self.transforms = transforms.Compose([
            transforms.Resize((hr_height, hr_width), Image.BICUBIC),
            transforms.ToTensor(),
            transforms.Normalize(mean, std),
        ])
        self.class_names = sorted(os.listdir(root))
        self.class_to_idx = {class_name: idx for idx, class_name in enumerate(self.class_names)}
        self.files = []
        for class_name in self.class_names:
            class_dir = os.path.join(root, class_name)
            class_idx = self.class_to_idx[class_name]
            class_files = [(file, class_idx) for file in glob.glob(class_dir + '/*.*')]
            self.files.extend(class_files)

    def __getitem__(self, index):
        img_path, label = self.files[index]
        img = Image.open(img_path)
        img = self.transforms(img)

        # Flatten the image to 30000 features
        img = img.view(-1, 30000)

        return img, label

    def __len__(self):
        return len(self.files)
