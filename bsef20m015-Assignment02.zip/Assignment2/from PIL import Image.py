from PIL import Image

# Load an example image from your dataset
image_path = 'C:\\Users\\Laiba Ahmad\\Downloads\\Sign-Language-Digits-Dataset-master (1)\\Sign-Language-Digits-Dataset-master\\Dataset\\0\\IMG_1118.jpg'


image = Image.open(image_path)

# Get the size (width and height) of the image
width, height = image.size

print(f"Image width: {width}, Image height: {height}")
