import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from customDataset import SignDataset

class NN(nn.Module):
    def __init__(self, input_size, num_classes):
        super(NN, self).__init__()
        self.fc1 = nn.Linear(input_size, 50)
        self.fc2 = nn.Linear(50, num_classes)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
input_size = 30000  # Update input size to 30000
num_classes = 10  # Modify this according to your number of classes
learning_rate = 0.001
num_epochs = 4

model = NN(input_size=input_size, num_classes=num_classes).to(device)
criterion = nn.CrossEntropyLoss()  # Use Cross Entropy Loss for multi-class classification
optimizer = optim.Adam(model.parameters(), lr=learning_rate)

custom_dataset = SignDataset('dataset images', hr_shape=(100, 100))  # Update hr_shape to (100, 100)
data_loader = DataLoader(custom_dataset, batch_size=64, shuffle=True)

for epoch in range(num_epochs):
    print(f"Epoch: {epoch}")
    for batch_idx, (images, labels) in enumerate(data_loader):
        images = images.to(device=device)
        labels = labels.to(device=device)

        # Reshape the images to match the input size
        images = images.view(images.size(0), -1)

        scores = model(images)
        loss = criterion(scores, labels)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

def check_accuracy(loader, model):
    num_correct = 0
    num_samples = 0
    model.eval()
    with torch.no_grad():
        for images, labels in loader:
            images = images.to(device=device)
            labels = labels.to(device=device)

            # Reshape the images to match the input size
            images = images.view(images.size(0), -1)

            scores = model(images)
            _, predictions = scores.max(1)
            num_correct += (predictions == labels).sum()
            num_samples += predictions.size(0)

        print(
            f"Got {num_correct} / {num_samples} with accuracy"
            f" {float(num_correct) / float(num_samples) * 100:.2f}"
        )

    model.train()

print("Train accuracy:")
check_accuracy(data_loader, model)
